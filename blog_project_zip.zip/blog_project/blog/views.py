from django.shortcuts import render, redirect, get_object_or_404
from .models import BlogPost, Comment, UserProfile, Tag
from .forms import BlogPostForm, CommentForm, UserProfileForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login, logout
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseNotAllowed

# Home page with pagination
def home(request):
    posts = BlogPost.objects.all()  # Get all blog posts
    paginator = Paginator(posts, 5)  # Show 5 posts per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'home.html', {'page_obj': page_obj})

# Create Blog Post
def create_post(request):
    if request.method == 'POST':
        form = BlogPostForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user  # Set the current logged-in user as the author
            post.save()
            return redirect('home')  # Redirect to a success page (e.g., home)
    else:
        form = BlogPostForm()
    
    return render(request, 'create_post.html', {'form': form})

# User registration
def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('profile')
    else:
        form = UserCreationForm()
    return render(request, 'blog/register.html', {'form': form})


#logout 
def logout_view(request):
    logout(request)
    return render(request, 'blog/logout.html')

# User profile
@login_required
def profile(request):
    try:
        profile = UserProfile.objects.get(user=request.user)
    except UserProfile.DoesNotExist:
        profile = None
    posts = BlogPost.objects.filter(author=request.user)
    return render(request, 'blog/profile.html', {'profile': profile, 'posts': posts})

# Post create/edit
def post_create_edit(request, post_id=None):
    if post_id:
        post = get_object_or_404(BlogPost, id=post_id)
    else:
        post = None
    if request.method == 'POST':
        form = BlogPostForm(request.POST, instance=post)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = BlogPostForm(instance=post)
    return render(request, 'blog/post_create_edit.html', {'form': form})

# Delete Blog Post
def post_delete(request, post_id):
    post = get_object_or_404(BlogPost, id=post_id)
    post.delete()
    return redirect('home')

# Post comment
def post_comment(request, post_id):
    post = get_object_or_404(BlogPost, id=post_id)
    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.post = post
            comment.author = request.user
            comment.save()
            return redirect('post_detail', post_id=post.id)
    else:
        form = CommentForm()
    return render(request, 'blog/post_comment.html', {'form': form, 'post': post})

# Post detail page with like/dislike functionality

def post_detail(request, post_id):
    post = get_object_or_404(BlogPost, id=post_id)
    is_liked = post.likes.filter(id=request.user.id).exists()
    is_disliked = post.dislikes.filter(id=request.user.id).exists()
    
    if request.method == 'POST':
        if 'like' in request.POST:
            if is_liked:
                post.likes.remove(request.user)
            else:
                post.likes.add(request.user)
            post.dislikes.remove(request.user)
        if 'dislike' in request.POST:
            if is_disliked:
                post.dislikes.remove(request.user)
            else:
                post.dislikes.add(request.user)
            post.likes.remove(request.user)
        return redirect('post_detail', post_id=post.id)

    return render(request, 'blog/post_detail.html', {'post': post, 'is_liked': is_liked, 'is_disliked': is_disliked})
