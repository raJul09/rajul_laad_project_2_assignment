from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    # Home page
    path('', views.home, name='home'),
    
    # User registration
    path('register/', views.register, name='register'),
    
    # User profile
    path('profile/', views.profile, name='profile'),
    
    # Create new post
    path('create_post/', views.create_post, name='create_post'),
    
    # Edit existing post
    path('edit_post/<int:post_id>/', views.post_create_edit, name='edit_post'),
    
    # Delete a post
    path('delete_post/<int:post_id>/', views.post_delete, name='delete_post'),
    
    # Post comments
    path('post_comment/<int:post_id>/', views.post_comment, name='post_comment'),
    
    # Post detail page
    path('post_detail/<int:post_id>/', views.post_detail, name='post_detail'),
    
    # Login view
    path('login/', auth_views.LoginView.as_view(), name='login'),
    
    # Logout view
    path('logout/', views.logout_view, name='logout'),
    
    # Password reset views
    path('password_reset/', auth_views.PasswordResetView.as_view(), name='password_reset'),
    path('password_reset_done/', auth_views.PasswordResetDoneView.as_view(), name='password_reset_done'),
    path('password_reset_confirm/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('password_reset_complete/', auth_views.PasswordResetCompleteView.as_view(), name='password_reset_complete'),
]
