# blog/forms.py
from django import forms
from .models import BlogPost, Comment, UserProfile, Tag

class BlogPostForm(forms.ModelForm):

    class Meta:
        model = BlogPost
        fields = ['title', 'body', 'tags']

        tag = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={'placeholder': 'Enter tags separated by commas'}))

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['body']

class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['bio', 'profile_picture']
